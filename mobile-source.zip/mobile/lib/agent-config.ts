import Constants from "expo-constants";

const extra = (Constants.expoConfig?.extra ?? {}) as Record<string, string | undefined>;

export const agentConfig = {
  apiBaseUrl: extra.agentApiUrl ?? process.env.EXPO_PUBLIC_AGENT_API_URL ?? "",
  supabaseUrl: extra.supabaseUrl ?? process.env.EXPO_PUBLIC_SUPABASE_URL ?? "",
  supabaseAnonKey: extra.supabaseAnonKey ?? process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? "",
  workspaceId: extra.workspaceId ?? process.env.EXPO_PUBLIC_AGENT_WORKSPACE_ID ?? "",
  expoProjectId: extra.expoProjectId ?? process.env.EXPO_PUBLIC_EXPO_PROJECT_ID ?? "",
};

export const isConfigured = Boolean(
  agentConfig.apiBaseUrl && agentConfig.supabaseUrl && agentConfig.supabaseAnonKey,
);
