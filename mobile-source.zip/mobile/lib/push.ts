import { Platform } from "react-native";
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
import * as SecureStore from "expo-secure-store";
import { agentConfig } from "./agent-config";
import { AgentApi } from "./agent-api";

const INSTALLATION_ID = "agent-core.installation-id";

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
});

async function installationId() {
  let id = await SecureStore.getItemAsync(INSTALLATION_ID);
  if (!id) {
    id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (character) => {
      const random = Math.floor(Math.random() * 16);
      const value = character === "x" ? random : (random & 0x3) | 0x8;
      return value.toString(16);
    });
    await SecureStore.setItemAsync(INSTALLATION_ID, id);
  }
  return id;
}

export async function registerPushDevice() {
  if (Platform.OS === "web" || !Device.isDevice) return { registered: false, reason: "not-a-physical-device" };
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("approvals", {
      name: "Schválení agenta",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 180, 100, 180],
      lightColor: "#4D9BFF",
    });
  }
  const existing = await Notifications.getPermissionsAsync();
  const permission = existing.status === "granted" ? existing : await Notifications.requestPermissionsAsync();
  if (permission.status !== "granted") return { registered: false, reason: "permission-denied" };
  if (!agentConfig.expoProjectId) return { registered: false, reason: "missing-project-id" };
  const token = await Notifications.getExpoPushTokenAsync({ projectId: agentConfig.expoProjectId });
  await AgentApi.registerDevice({
    installation_id: await installationId(),
    platform: Platform.OS === "ios" ? "ios" : "android",
    expo_push_token: token.data,
    app_version: "1.0.0",
    notification_permissions: "granted",
  });
  return { registered: true };
}
