import "react-native-url-polyfill/auto";
import { Platform } from "react-native";
import * as SecureStore from "expo-secure-store";
import { createClient } from "@supabase/supabase-js";
import { agentConfig, isConfigured } from "./agent-config";

function getWebSessionStorage(): Storage | null {
  if (Platform.OS !== "web" || typeof globalThis === "undefined") return null;
  return globalThis.sessionStorage ?? null;
}

const storage = {
  getItem: async (key: string) => {
    if (Platform.OS === "web") return getWebSessionStorage()?.getItem(key) ?? null;
    return SecureStore.getItemAsync(key);
  },
  setItem: async (key: string, value: string) => {
    if (Platform.OS === "web") {
      getWebSessionStorage()?.setItem(key, value);
      return;
    }
    await SecureStore.setItemAsync(key, value, {
      keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
    });
  },
  removeItem: async (key: string) => {
    if (Platform.OS === "web") {
      getWebSessionStorage()?.removeItem(key);
      return;
    }
    await SecureStore.deleteItemAsync(key);
  },
};

const WORKSPACE_KEY = "agent-core.active-workspace";

export const supabase = createClient(
  agentConfig.supabaseUrl || "https://configuration-required.invalid",
  agentConfig.supabaseAnonKey || "configuration-required",
  {
    auth: {
      storage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  },
);

export async function sendMagicLink(email: string) {
  if (!isConfigured) throw new Error("Aplikace ještě nemá bezpečně nastavené připojení k Agent Core.");
  const redirectTo = "agentcore://auth/callback";
  const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: redirectTo } });
  if (error) throw error;
}

export async function getAccessToken(): Promise<string> {
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.access_token) throw new Error("Relace vypršela. Přihlaste se znovu.");
  return data.session.access_token;
}

export async function getActiveWorkspaceId(): Promise<string> {
  const cached = await storage.getItem(WORKSPACE_KEY);
  if (cached) return cached;
  const { data, error } = await supabase.rpc("bootstrap_personal_workspace");
  if (error || !data) throw new Error(error?.message ?? "Nepodařilo se vytvořit osobní workspace.");
  await storage.setItem(WORKSPACE_KEY, data as string);
  return data as string;
}
