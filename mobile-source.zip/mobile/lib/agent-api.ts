import { agentConfig, isConfigured } from "./agent-config";
import { getAccessToken, getActiveWorkspaceId } from "./agent-auth";

export type Dashboard = {
  summary: { pending_approvals: number; active_runs: number; open_tasks: number };
  recent_runs: Array<{ id: string; intent: string; status: string; model_profile: string; created_at: string }>;
};

export type Approval = {
  id: string;
  title: string;
  rationale: string;
  risk_summary: string;
  proposed_change?: Record<string, unknown>;
  rollback_plan?: string | null;
  status: "pending" | "approved" | "rejected" | "expired";
  expires_at: string;
  version: number;
};

export type AgentRun = { run_id: string; status: string; idempotent_replay?: boolean };

async function request<T>(path: string, options: RequestInit = {}, idempotency = false): Promise<T> {
  if (!isConfigured) throw new Error("Připojení k Agent Core není nastavené.");
  const token = await getAccessToken();
  const response = await fetch(`${agentConfig.apiBaseUrl.replace(/\/$/, "")}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(idempotency ? { "Idempotency-Key": `${Date.now()}-${Math.random().toString(36).slice(2)}` } : {}),
      ...(options.headers ?? {}),
    },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail ?? `Server vrátil chybu ${response.status}.`);
  return body as T;
}

export const AgentApi = {
  dashboard: async () => request<Dashboard>(`/v1/dashboard?workspace_id=${encodeURIComponent(await getActiveWorkspaceId())}`),
  approvals: async () => request<{ items: Approval[] }>(`/v1/approvals?workspace_id=${encodeURIComponent(await getActiveWorkspaceId())}&pending_only=true`),
  approval: (id: string) => request<Approval>(`/v1/approvals/${id}`),
  decideApproval: (id: string, decision: "approved" | "rejected", version: number, note: string) =>
    request(`/v1/approvals/${id}/decision`, { method: "POST", body: JSON.stringify({ decision, version, note }) }),
  createTask: async (title: string, instructions: string, priority: number) =>
    request("/v1/tasks", { method: "POST", body: JSON.stringify({ workspace_id: await getActiveWorkspaceId(), title, instructions, priority }) }, true),
  createThread: async (title: string) => request<{ id: string }>("/v1/threads", { method: "POST", body: JSON.stringify({ workspace_id: await getActiveWorkspaceId(), title }) }),
  sendMessage: (threadId: string, content: string) =>
    request<AgentRun>(`/v1/threads/${threadId}/messages`, { method: "POST", body: JSON.stringify({ content, model_profile: "fast_free", permitted_tool_categories: [] }) }, true),
  getRun: (runId: string) => request<{ status: string; output?: { text?: string }; error_detail?: string }>(`/v1/runs/${runId}`),
  registerDevice: (payload: Record<string, string>) => request("/v1/mobile/devices/register", { method: "POST", body: JSON.stringify(payload) }),
};
