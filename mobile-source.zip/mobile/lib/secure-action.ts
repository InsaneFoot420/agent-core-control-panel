import * as LocalAuthentication from "expo-local-authentication";

export async function requireApprovalConfirmation() {
  const hasHardware = await LocalAuthentication.hasHardwareAsync();
  const isEnrolled = await LocalAuthentication.isEnrolledAsync();
  if (!hasHardware || !isEnrolled) return true;
  const result = await LocalAuthentication.authenticateAsync({
    promptMessage: "Potvrďte rozhodnutí pro agenta",
    promptDescription: "Schválení provede externí změnu.",
    fallbackLabel: "Použít kód zařízení",
    requireConfirmation: true,
  });
  return result.success;
}
