import { ReactNode } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View, ViewStyle } from "react-native";

export const palette = {
  background: "#091221", surface: "#12213A", border: "#263A5A", text: "#EAF1FC", muted: "#93A4BE",
  blue: "#4D9BFF", green: "#36C98D", amber: "#F5B642", red: "#F06A73",
};

export function Card({ children, style }: { children: ReactNode; style?: ViewStyle }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function SectionTitle({ children, action }: { children: string; action?: ReactNode }) {
  return <View style={styles.sectionTitle}><Text style={styles.heading}>{children}</Text>{action}</View>;
}

export function PrimaryButton({ title, onPress, disabled, tone = "blue" }: { title: string; onPress: () => void; disabled?: boolean; tone?: "blue" | "green" | "red" }) {
  const color = tone === "green" ? palette.green : tone === "red" ? palette.red : palette.blue;
  return <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.button, { backgroundColor: color }, (pressed || disabled) && styles.buttonPressed]}><Text style={styles.buttonText}>{disabled ? "Provádím…" : title}</Text></Pressable>;
}

export function EmptyState({ title, description }: { title: string; description: string }) {
  return <View style={styles.empty}><Text style={styles.emptyTitle}>{title}</Text><Text style={styles.emptyDescription}>{description}</Text></View>;
}

export function LoadingBlock() {
  return <View style={styles.loading}><ActivityIndicator color={palette.blue} /></View>;
}

const styles = StyleSheet.create({
  card: { backgroundColor: palette.surface, borderColor: palette.border, borderWidth: 1, borderRadius: 18, padding: 16 },
  sectionTitle: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  heading: { color: palette.text, fontSize: 20, fontWeight: "700", letterSpacing: -0.3 },
  button: { alignItems: "center", borderRadius: 13, justifyContent: "center", minHeight: 48, paddingHorizontal: 18 },
  buttonPressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
  buttonText: { color: "#07111F", fontWeight: "800", fontSize: 16 },
  empty: { alignItems: "center", paddingHorizontal: 20, paddingVertical: 26 },
  emptyTitle: { color: palette.text, fontSize: 17, fontWeight: "700", marginBottom: 6 },
  emptyDescription: { color: palette.muted, fontSize: 14, lineHeight: 20, textAlign: "center" },
  loading: { paddingVertical: 28, alignItems: "center" },
});
