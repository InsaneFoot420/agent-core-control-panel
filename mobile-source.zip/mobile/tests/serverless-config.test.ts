import { describe, expect, it } from "vitest";

const apiBaseUrl = process.env.EXPO_PUBLIC_AGENT_API_URL ?? "";
const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL ?? "";
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? "";
const workspaceId = process.env.EXPO_PUBLIC_AGENT_WORKSPACE_ID ?? "";

describe("serverless Agent Core configuration", () => {
  it("odpovídá veřejné konfiguraci nasazeného serverless API", async () => {
    expect(apiBaseUrl).toMatch(/^https:\/\//);
    expect(supabaseUrl).toMatch(/^https:\/\//);
    expect(supabaseAnonKey.length).toBeGreaterThan(20);
    expect(workspaceId).toMatch(/^[0-9a-f-]{36}$/i);

    const response = await fetch(`${apiBaseUrl}/public-config`);
    expect(response.ok).toBe(true);
    const config = await response.json() as Record<string, string>;
    expect(config.api_base_url).toBe(apiBaseUrl);
    expect(config.supabase_url).toBe(supabaseUrl);
    expect(config.supabase_anon_key).toBe(supabaseAnonKey);
    expect(config.workspace_id).toBe(workspaceId);
  });
});
