import { describe, expect, it } from "vitest";

const apiBaseUrl = process.env.EXPO_PUBLIC_AGENT_API_URL;

describe("serverless Agent Core API", () => {
  it("odpovídá ze zdravotního endpointu na nastavené veřejné adrese", async () => {
    expect(apiBaseUrl).toMatch(/^https:\/\/[^\s]+$/);

    const response = await fetch(`${apiBaseUrl!.replace(/\/$/, "")}/healthz`);
    expect(response.ok).toBe(true);
    await expect(response.json()).resolves.toMatchObject({ status: "ok", service: "agent-core-api" });
  }, 15_000);
});
