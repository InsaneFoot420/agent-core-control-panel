import { Alert, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { Stack, router } from "expo-router";
import { useState } from "react";
import * as Notifications from "expo-notifications";
import { supabase } from "@/lib/agent-auth";
import { registerPushDevice } from "@/lib/push";
import { Card, palette, PrimaryButton } from "@/components/agent-ui";
import { ScreenContainer } from "@/components/screen-container";

export default function SettingsScreen() {
  const [pushEnabled, setPushEnabled] = useState(true); const [busy, setBusy] = useState(false);
  const updatePush = async (next: boolean) => { setPushEnabled(next); if (next) { try { setBusy(true); const result = await registerPushDevice(); if (!result.registered) Alert.alert("Notifikace čekají na dokončení", "Povolte je prosím v nastavení telefonu."); } catch (error) { Alert.alert("Notifikace nelze nastavit", error instanceof Error ? error.message : "Zkuste to znovu."); } finally { setBusy(false); } } else { Alert.alert("Ztlumeno", "Aplikace nebude registrovat nové notifikační tokeny. Stávající token lze odvolat po odhlášení."); } };
  const logout = async () => { await supabase.auth.signOut(); router.replace("/(tabs)" as never); };
  return <ScreenContainer className="p-4" edges={["top", "bottom", "left", "right"]}><Stack.Screen options={{ headerShown: true, headerTitle: "Nastavení", headerStyle: { backgroundColor: palette.background }, headerTintColor: palette.text }} /><ScrollView contentContainerStyle={styles.scroll}><Text style={styles.copy}>Ovládáte pouze klientské předvolby. Provider klíče a oprávnění nástrojů zůstávají pouze na serveru.</Text><Card><Text style={styles.heading}>Notifikace schválení</Text><View style={styles.row}><View style={{ flex: 1 }}><Text style={styles.item}>Okamžité žádosti</Text><Text style={styles.copy}>Agent pošle upozornění, když čeká na vaše rozhodnutí.</Text></View><Switch value={pushEnabled} onValueChange={updatePush} disabled={busy} trackColor={{ false: palette.border, true: palette.blue }} /></View></Card><Card><Text style={styles.heading}>Bezpečnost</Text><Text style={styles.item}>Biometrické potvrzení</Text><Text style={styles.copy}>Před schválením externí změny aplikace požádá o Face ID, otisk nebo kód zařízení, je-li dostupný.</Text></Card><Card><Text style={styles.heading}>Relace</Text><Text style={styles.copy}>Odhlášení odstraní relaci z tohoto telefonu. Nezmění stav agentních běhů ani dat na serveru.</Text><View style={{ marginTop: 13 }}><PrimaryButton title="Odhlásit tento telefon" tone="red" onPress={logout} /></View></Card></ScrollView></ScreenContainer>;
}
const styles = StyleSheet.create({ scroll: { gap: 13, paddingBottom: 10, paddingTop: 10 }, heading: { color: palette.text, fontSize: 18, fontWeight: "800", marginBottom: 11 }, item: { color: palette.text, fontSize: 16, fontWeight: "700", marginBottom: 4 }, copy: { color: palette.muted, fontSize: 14, lineHeight: 20 }, row: { alignItems: "center", flexDirection: "row", gap: 12 } });
