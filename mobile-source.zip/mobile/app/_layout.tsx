import { useEffect } from "react";
import { Stack, router } from "expo-router";
import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "@/lib/theme-provider";
import "@/global.css";

const client = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 10_000 } } });

function useApprovalDeepLinks() {
  useEffect(() => {
    if (Platform.OS === "web") return;

    const open = (notification: Notifications.Notification) => {
      const approvalId = notification.request.content.data?.approval_id;
      if (typeof approvalId === "string") router.push({ pathname: "/approval/[id]", params: { id: approvalId } } as never);
    };
    Notifications.getLastNotificationResponseAsync().then((response) => response?.notification && open(response.notification));
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => open(response.notification));
    return () => subscription.remove();
  }, []);
}

export default function RootLayout() {
  useApprovalDeepLinks();
  return <SafeAreaProvider><ThemeProvider><QueryClientProvider client={client}><Stack screenOptions={{ headerShown: false, animation: "fade" }}><Stack.Screen name="(tabs)" /><Stack.Screen name="approval/[id]" options={{ presentation: "card" }} /></Stack></QueryClientProvider></ThemeProvider></SafeAreaProvider>;
}
