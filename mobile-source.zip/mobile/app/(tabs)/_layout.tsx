import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { palette } from "@/components/agent-ui";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const paddingBottom = Platform.OS === "web" ? 10 : Math.max(9, insets.bottom);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: palette.blue, tabBarInactiveTintColor: palette.muted, tabBarStyle: { backgroundColor: palette.background, borderTopColor: palette.border, height: 57 + paddingBottom, paddingTop: 7, paddingBottom }, tabBarLabelStyle: { fontWeight: "600" } }}>
    <Tabs.Screen name="index" options={{ title: "Domů", tabBarIcon: ({ color }) => <IconSymbol name="house.fill" size={24} color={color} /> }} />
    <Tabs.Screen name="chat" options={{ title: "Chat", tabBarIcon: ({ color }) => <IconSymbol name="paperplane.fill" size={24} color={color} /> }} />
    <Tabs.Screen name="approvals" options={{ title: "Schválení", tabBarIcon: ({ color }) => <IconSymbol name="checkmark.shield.fill" size={24} color={color} /> }} />
    <Tabs.Screen name="tasks" options={{ title: "Úkoly", tabBarIcon: ({ color }) => <IconSymbol name="checklist" size={24} color={color} /> }} />
  </Tabs>;
}
