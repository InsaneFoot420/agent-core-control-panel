# Připojení Agent Core Mobile k notebookovému serveru

Po dokončení notebookového instalátoru vypíše terminál veřejnou adresu ve formátu `https://agent-core.<tailnet>.ts.net`. Tato adresa se použije jako `EXPO_PUBLIC_AGENT_API_URL` před vytvořením finálního Android buildu.

Proměnné `EXPO_PUBLIC_SUPABASE_URL`, `EXPO_PUBLIC_SUPABASE_ANON_KEY` a `EXPO_PUBLIC_AGENT_WORKSPACE_ID` zůstávají identické se stávajícím projektem Supabase. Nikdy nevkládejte do mobilní aplikace service-role klíč Supabase, klíče Gemini/Groq ani token Tailscale.

| Konfigurační hodnota | Zdroj | Místo použití |
|---|---|---|
| `EXPO_PUBLIC_AGENT_API_URL` | Výstup notebookového instalátoru | Veřejné HTTPS API Agent Core |
| `EXPO_PUBLIC_SUPABASE_URL` | Nastavení projektu Supabase | Přihlášení a data uživatele |
| `EXPO_PUBLIC_SUPABASE_ANON_KEY` | Nastavení projektu Supabase | Veřejný klientský klíč s RLS |
| `EXPO_PUBLIC_AGENT_WORKSPACE_ID` | Úvodní workspace v Supabase | Výchozí pracovní prostor UI |

Mobilní aplikace načítá tyto hodnoty z Expo konfigurace a zachovává přístupový token uživatele v bezpečném úložišti zařízení. Webový náhled používá bezpečný fallback pro prostředí bez `sessionStorage`.
