# Agent Core Mobile — návrh rozhraní

## Produktový záměr

Agent Core Mobile je nativní operační panel pro osobního AI agenta. Je optimalizovaný pro **portrétní ovládání jednou rukou** na telefonu 9:16. Primární situace je krátké rozhodnutí z notifikace: uživatel musí během několika sekund vidět, co agent chce změnit, jaké je riziko, a zda akci schválit nebo zamítnout. Dlouhé plánování a čtení dokumentace zůstává dostupné, ale neovládá hlavní tok aplikace.

## Obrazovky a obsah

| Obrazovka | Primární obsah | Hlavní funkce |
|---|---|---|
| Přihlášení | Stav relace, bezpečné přihlášení a vysvětlení oprávnění | Obnovení relace, přihlášení přes Supabase a uložení tokenu do bezpečného úložiště. |
| Domů | Karta nejbližšího schválení, aktivní běhy, souhrn úkolů a zdravotní stav | Rychlý přechod na approval inbox, ruční obnovení a založení nového úkolu. |
| Schválení | Název akce, důvod, riziko, návrh změny, plán návratu a čas do expirace | Biometrické potvrzení, schválit, zamítnout a přidat poznámku. |
| Chat | Vlákna, zprávy, odpovědi agenta a citace zdrojů | Poslat dotaz, založit vlákno a sledovat stav běhu. |
| Úkoly | Otevřené úkoly podle priority a stav zpracování | Vytvořit nový úkol, zobrazit stav a zrušit bezpečně běžící práci. |
| Projekt | Stav projektu, poslední běhy, zdroje znalostní báze a souhrn rizik | Přepnutí projektu a dohledání auditní stopy. |
| Nastavení | Notifikační oprávnění, zařízení, biometrický zámek a odhlášení | Registrovat push token, změnit předvolby a odvolat lokální zařízení. |

## Klíčové toky

1. Agent požádá o externí změnu → backend vytvoří request → telefon přijme push → uživatel klepne na notifikaci → otevře se detail schválení → aplikace ověří biometriku → uživatel zvolí Schválit nebo Zamítnout → API stav atomicky zapíše → aplikace zobrazí průběh a výsledek.

2. Uživatel otevře Domů → zkontroluje běhy a počet čekajících rozhodnutí → klepne na „Nový úkol“ → vyplní cíl a prioritu → úkol se uloží do fronty → aplikace se vrátí na stav projektu.

3. Uživatel otevře Chat → odešle zprávu → aplikace zobrazí stav „Agent pracuje“ → opakovaně načítá stav běhu → zobrazí odpověď a zdroje.

## Navigace a ovládání

Spodní navigace obsahuje Domů, Chat, Schválení a Úkoly. Nastavení a detail projektu jsou sekundární obrazovky otevřené z avatara či karty projektu. Pro neodkladné schválení má vždy přednost deep link z push notifikace. Primární tlačítka jsou dole v dosahu palce, minimálně 44 pt vysoká, s jemnou haptickou odezvou. Rizikové akce nejsou pouze červená tlačítka: vždy ukazují objekt změny, dopad a čas expirace.

## Vizuální směr

Rozhraní odpovídá mainstreamovému iOS stylu: velké systémové titulky, vysoký kontrast, přirozené zaoblení, úsporné karty, standardní safe area a nativní SF Symbols na iOS. Tmavé pozadí podporuje práci večer i nižší spotřebu OLED displeje. Barevný systém je konkrétní pro Agent Core: **Midnight #091221** jako pozadí, **Slate #12213A** jako plocha karet, **Signal Blue #4D9BFF** pro hlavní akce, **Approve Green #36C98D** pro bezpečné potvrzení, **Attention Amber #F5B642** pro čekající rozhodnutí a **Deny Red #F06A73** pro zamítnutí či chybu. Text je Ice #EAF1FC a sekundární Steel #93A4BE.

## Bezpečnostní zásady UX

Aplikace nikdy nezobrazuje API klíče, plné credentials ani necenzurované interní logy. Push zpráva obsahuje jen stručný název akce; citlivý detail se načítá až po ověření relace. Schválení provede pouze API volání s aktuální verzí requestu, proto zastaralá notifikace nemůže potvrdit již změněnou akci.
