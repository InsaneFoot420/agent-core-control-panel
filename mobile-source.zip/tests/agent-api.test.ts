import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("expo-constants", () => ({
  default: {
    expoConfig: {
      extra: {
        agentApiUrl: "https://agent.example.test",
        supabaseUrl: "https://supabase.example.test",
        supabaseAnonKey: "public-anon-key",
        workspaceId: "00000000-0000-4000-8000-000000000001",
      },
    },
  },
}));

vi.mock("@/lib/agent-auth", () => ({
  getAccessToken: vi.fn(async () => "session-token"),
  getActiveWorkspaceId: vi.fn(async () => "00000000-0000-4000-8000-000000000001"),
}));

describe("AgentApi", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.stubGlobal("fetch", vi.fn());
  });

  it("odesílá rozhodnutí se session tokenem a verzí schválení", async () => {
    const mockedFetch = vi.mocked(fetch);
    mockedFetch.mockResolvedValue(new Response(JSON.stringify({ id: "approval-1", status: "approved", version: 4 }), { status: 200, headers: { "Content-Type": "application/json" } }));
    const { AgentApi } = await import("@/lib/agent-api");

    await AgentApi.decideApproval("approval-1", "approved", 3, "Schváleno z telefonu");

    expect(mockedFetch).toHaveBeenCalledWith(
      "https://agent.example.test/v1/approvals/approval-1/decision",
      expect.objectContaining({
        method: "POST",
        headers: expect.objectContaining({ Authorization: "Bearer session-token", "Content-Type": "application/json" }),
        body: JSON.stringify({ decision: "approved", version: 3, note: "Schváleno z telefonu" }),
      }),
    );
  });

  it("vkládá workspace ID pouze do těla požadavku na nový úkol", async () => {
    const mockedFetch = vi.mocked(fetch);
    mockedFetch.mockResolvedValue(new Response(JSON.stringify({ id: "task-1" }), { status: 201, headers: { "Content-Type": "application/json" } }));
    const { AgentApi } = await import("@/lib/agent-api");

    await AgentApi.createTask("Prověřit vydání", "Zkontroluj stav release kandidáta.", 2);

    const init = mockedFetch.mock.calls[0][1] as RequestInit;
    expect(init.body).toContain("00000000-0000-4000-8000-000000000001");
    expect(String(init.body)).not.toContain("public-anon-key");
  });

  it("registruje push zařízení přes chráněný endpoint se session tokenem", async () => {
    const mockedFetch = vi.mocked(fetch);
    mockedFetch.mockResolvedValue(new Response(JSON.stringify({ id: "device-1" }), { status: 201, headers: { "Content-Type": "application/json" } }));
    const { AgentApi } = await import("@/lib/agent-api");
    const payload = {
      expo_push_token: "ExponentPushToken[test-token]",
      installation_id: "install-1",
      platform: "android",
      app_version: "1.0.0",
      notification_permissions: "granted",
    };

    await AgentApi.registerDevice(payload);

    expect(mockedFetch).toHaveBeenCalledWith(
      "https://agent.example.test/v1/mobile/devices/register",
      expect.objectContaining({
        method: "POST",
        headers: expect.objectContaining({ Authorization: "Bearer session-token", "Content-Type": "application/json" }),
        body: JSON.stringify(payload),
      }),
    );
  });

  it("načítá notifikační inbox v rámci aktivního workspace", async () => {
    const mockedFetch = vi.mocked(fetch);
    mockedFetch.mockResolvedValue(new Response(JSON.stringify({ items: [] }), { status: 200, headers: { "Content-Type": "application/json" } }));
    const { AgentApi } = await import("@/lib/agent-api");

    await AgentApi.notifications();

    expect(mockedFetch).toHaveBeenCalledWith(
      "https://agent.example.test/v1/notifications?workspace_id=00000000-0000-4000-8000-000000000001",
      expect.objectContaining({ headers: expect.objectContaining({ Authorization: "Bearer session-token" }) }),
    );
  });

  it("vytváří samostatný desktopový token bez vložení veřejného anon klíče do požadavku", async () => {
    const mockedFetch = vi.mocked(fetch);
    mockedFetch.mockResolvedValue(new Response(JSON.stringify({ client: { id: "client-1" }, token: "ac_one_time" }), { status: 201, headers: { "Content-Type": "application/json" } }));
    const { AgentApi } = await import("@/lib/agent-api");

    await AgentApi.createDesktopClient({ name: "OpenCode", kind: "opencode", scopes: ["runs.read", "chat.write"] });

    const init = mockedFetch.mock.calls[0][1] as RequestInit;
    expect(mockedFetch).toHaveBeenCalledWith(
      "https://agent.example.test/v1/api-clients",
      expect.objectContaining({ method: "POST", headers: expect.objectContaining({ Authorization: "Bearer session-token" }) }),
    );
    expect(String(init.body)).toContain("00000000-0000-4000-8000-000000000001");
    expect(String(init.body)).not.toContain("public-anon-key");
  });
});
