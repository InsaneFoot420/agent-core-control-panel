import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { Stack, router } from "expo-router";
import { AgentApi, type AgentNotification } from "@/lib/agent-api";
import { Card, EmptyState, LoadingBlock, palette } from "@/components/agent-ui";
import { ScreenContainer } from "@/components/screen-container";

function notificationColor(kind: AgentNotification["kind"]) {
  if (kind === "security_alert" || kind === "run_failed") return palette.red;
  if (kind === "approval_required" || kind === "quota_warning") return palette.amber;
  return palette.blue;
}

export default function NotificationsScreen() {
  const client = useQueryClient();
  const notifications = useQuery({ queryKey: ["notifications"], queryFn: AgentApi.notifications, refetchInterval: 30_000 });
  const acknowledge = useMutation({ mutationFn: AgentApi.acknowledgeNotification, onSuccess: () => client.invalidateQueries({ queryKey: ["notifications"] }) });
  const open = (item: AgentNotification) => {
    if (!item.acknowledged_at) acknowledge.mutate(item.id);
    if (/^\/run\/[^/]+$/.test(item.deep_link)) router.push({ pathname: "/run/[id]", params: { id: item.deep_link.split("/").pop()! } } as never);
  };
  return <ScreenContainer className="p-4" edges={["top", "bottom", "left", "right"]}><Stack.Screen options={{ headerShown: true, headerTitle: "Centrum upozornění", headerStyle: { backgroundColor: palette.background }, headerTintColor: palette.text }} />{notifications.isLoading ? <LoadingBlock /> : <FlatList data={notifications.data?.items ?? []} contentContainerStyle={styles.list} keyExtractor={(item) => item.id} ListEmptyComponent={<EmptyState title="Žádná upozornění" description="Důležité stavy agentních běhů a schválení se zobrazí zde." />} renderItem={({ item }) => <Pressable onPress={() => open(item)} style={({ pressed }) => pressed && styles.pressed}><Card><View style={styles.head}><Text style={[styles.kind, { color: notificationColor(item.kind) }]}>{item.kind.replaceAll("_", " ")}</Text>{item.acknowledged_at ? <Text style={styles.ack}>Přečteno</Text> : <Text style={styles.new}>Nové</Text>}</View><Text style={styles.title}>{item.title}</Text><Text style={styles.copy}>{item.body}</Text><Text style={styles.time}>{new Date(item.created_at).toLocaleString("cs-CZ")}</Text></Card></Pressable>} />}</ScreenContainer>;
}
const styles = StyleSheet.create({ list: { gap: 11, paddingBottom: 18 }, pressed: { opacity: 0.72 }, head: { alignItems: "center", flexDirection: "row", justifyContent: "space-between", marginBottom: 7 }, kind: { fontSize: 11, fontWeight: "800", letterSpacing: 0.7, textTransform: "uppercase" }, ack: { color: palette.muted, fontSize: 12, fontWeight: "700" }, new: { color: palette.blue, fontSize: 12, fontWeight: "800" }, title: { color: palette.text, fontSize: 17, fontWeight: "800", marginBottom: 4 }, copy: { color: palette.muted, fontSize: 14, lineHeight: 20 }, time: { color: palette.muted, fontSize: 12, marginTop: 10 } });
