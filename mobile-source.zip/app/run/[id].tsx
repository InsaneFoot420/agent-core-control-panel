import { useQuery } from "@tanstack/react-query";
import { ScrollView, StyleSheet, Text } from "react-native";
import { Stack, useLocalSearchParams } from "expo-router";
import { AgentApi } from "@/lib/agent-api";
import { Card, LoadingBlock, palette } from "@/components/agent-ui";
import { ScreenContainer } from "@/components/screen-container";

export default function RunDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const run = useQuery({ queryKey: ["run", id], queryFn: () => AgentApi.getRun(id), refetchInterval: (query) => ["queued", "planning", "running", "waiting_approval"].includes(query.state.data?.status ?? "") ? 4000 : false });
  return <ScreenContainer className="p-4" edges={["top", "bottom", "left", "right"]}><Stack.Screen options={{ headerShown: true, headerTitle: "Detail běhu", headerStyle: { backgroundColor: palette.background }, headerTintColor: palette.text }} />{run.isLoading ? <LoadingBlock /> : <ScrollView contentContainerStyle={styles.scroll}><Card><Text style={styles.label}>STAV</Text><Text style={styles.status}>{run.data?.status ?? "Neznámý"}</Text></Card>{run.data?.output?.text ? <Card><Text style={styles.label}>VÝSLEDEK</Text><Text style={styles.result}>{run.data.output.text}</Text></Card> : null}{run.data?.error_detail ? <Card><Text style={[styles.label, { color: palette.red }]}>DIAGNOSTIKA</Text><Text style={styles.error}>{run.data.error_detail}</Text></Card> : null}</ScrollView>}</ScreenContainer>;
}
const styles = StyleSheet.create({ scroll: { gap: 12, paddingBottom: 18 }, label: { color: palette.muted, fontSize: 11, fontWeight: "800", letterSpacing: 1 }, status: { color: palette.blue, fontSize: 24, fontWeight: "800", marginTop: 7 }, result: { color: palette.text, fontSize: 16, lineHeight: 24, marginTop: 8 }, error: { color: palette.red, fontSize: 15, lineHeight: 22, marginTop: 8 } });
