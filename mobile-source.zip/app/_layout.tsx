import { useEffect } from "react";
import { Stack, router } from "expo-router";
import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "@/lib/theme-provider";
import "@/global.css";

const client = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 10_000 } } });

function useAgentDeepLinks() {
  useEffect(() => {
    if (Platform.OS === "web") return;

    const open = (notification: Notifications.Notification) => {
      const data = notification.request.content.data ?? {};
      const approvalId = data.approval_id;
      const url = data.url;
      if (typeof approvalId === "string") {
        router.push({ pathname: "/approval/[id]", params: { id: approvalId } } as never);
      } else if (typeof url === "string" && /^\/run\/[^/]+$/.test(url)) {
        router.push({ pathname: "/run/[id]", params: { id: url.split("/").pop()! } } as never);
      } else {
        router.push("/notifications" as never);
      }
    };
    Notifications.getLastNotificationResponseAsync().then((response) => response?.notification && open(response.notification));
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => open(response.notification));
    return () => subscription.remove();
  }, []);
}

export default function RootLayout() {
  useAgentDeepLinks();
  return <SafeAreaProvider><ThemeProvider><QueryClientProvider client={client}><Stack screenOptions={{ headerShown: false, animation: "fade" }}><Stack.Screen name="(tabs)" /><Stack.Screen name="approval/[id]" options={{ presentation: "card" }} /><Stack.Screen name="run/[id]" options={{ presentation: "card" }} /><Stack.Screen name="notifications" options={{ presentation: "card" }} /><Stack.Screen name="desktop-clients" options={{ presentation: "card" }} /></Stack></QueryClientProvider></ThemeProvider></SafeAreaProvider>;
}
